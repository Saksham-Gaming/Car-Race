var canvas, backgroundImage;

var playerCount;
var allPlayers;
var distance = 0;
var database;

var player1, player2, player3, player4;
var form, player, game;

var cars, car1, car2, car3, car4;

var carImg, car2Img, car3Img, car4Img, ground, track;

var closedRoom = false;

function preload() {
  carImg = loadImage("../images/car1.png");
  car2Img = loadImage("../images/car2.png");
  car3Img = loadImage("../images/car3.png");
  car4Img = loadImage("../images/car4.png");
  ground = loadImage("../images/ground.png");
  track = loadImage("../images/track.png");  
}


function setup(){
  canvas = createCanvas(displayWidth - 20, displayHeight-30);
  database = firebase.database();
  game = new Game();
  game.tryGetOpenRoom();
  game.start();

  form = new Form();
  form.display();
}


function draw(){
  //game.closeRoomAt4();
  if(game.playerCount === 4){
    //game.update(1);
  }
  if(game.gameState === 1){
    clear();
    game.play();
  }
  if (game.gameState === 2) {
    game.localEnd = false;
    game.end();
    //  game.update(2);
  }
}
