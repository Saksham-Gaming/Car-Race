class Game {
  
  constructor() {
    this.localEnd = false;
    this.playerCount = null;
    this.gameRoomKey = null;
    this.gameState = null;
    this.isHost = false;
    this.playerNum = null;
    this.playerObjects = new Array(4);
  }

/*
  closeRoomAt4() {
    if (this.isHost) {
      if (this.playerCount == 4) {
        if (closedRoom == false) {
          database.ref('/').update({
            openGame: "full"
           });
           console.log("repeat");
           closedRoom = true;
         }
       }
      }
  }
*/

  

    //Trys to find an open room, if there is no open room it will create a room
    tryGetOpenRoom() {
    var openRoomRef = database.ref('openGame').once('value').then((snapshot) => {
      this.gameRoomKey = snapshot.val();
      if (this.gameRoomKey == "full") {
        console.log("full");
        //Makes a Random Key For the Room
        this.gameRoomKey = database.ref('/').push().key;
        this.createRoom();
        //Joins the Room created
        this.joinRoom();
      } else {
        this.joinRoom();
      }
    }, (error) => {
      if (error) {
        console.log("error");
      } else {
        console.log("sucess");
      }
    });
  }
  //Create a room if the openGame server variable is set to "full"
  createRoom() {
    //Make this client the host, this client will send most of the changes to the server
    this.isHost = true;
    //Setup the room with its unique key
    this.gameState = 0;
    database.ref('/' + this.gameRoomKey).set({
      carEnd: 0,
      gameState: this.gameState,
      playerCount: 0
    }, (error) => {
      if (error) {
        console.log("error");
      } else {
        console.log("sucess");
      }
    });
    //Update the openGame server variable to be updated to this new room
    database.ref('/').update({
      openGame: this.gameRoomKey
    });
  }
  //Join the Room from the openGame server variable
  async joinRoom() {
    //Waits for the player count to arive before proceeding
    await this.getPlayerCountOnce();
    this.getPlayerCount();
    //console.log("1." + this.playerCount);
    this.playerCount += 1;
    //console.log("2." + this.playerCount);
    this.updatePlayerCount();
    //Gets this Clients Player Number
    this.playerNum = this.playerCount;
    //Creates a player object
    
    this.playerObjects[0] = new Player(this.playerNum);
    //Creates a player object on the server
    this.createServerPlayer(this.playerObjects[0]);
  }

  //Update The Player Count Number On The Database
  updatePlayerCount() {
    database.ref('/' + this.gameRoomKey + '/').update({
      playerCount: this.playerCount
    }, (error) => {
      if (error) {
        console.log("erorr");
      } else {
        console.log("success")
      }
    });
  }
  //Gets the current player count
  async getPlayerCountOnce() {
    await database.ref('/' + this.gameRoomKey + '/playerCount').once('value').then((snapshot) =>  {
      this.playerCount = snapshot.val();
      //console.log(this.playerCount);
    });
  }

  //Puts a listner on the playerCount server variable whenever it changes and then it will update this game object's player count variable
  getPlayerCount() {
    database.ref('/' + this.gameRoomKey + '/playerCount').on("value", (snapshot) => {
      this.playerCount = snapshot.val();
      //console.log("3rd" + this.playerCount);
    });
  }

  //Creates a Player
  createServerPlayer(player) {
    database.ref('/' + this.gameRoomKey + '/players/' + player.playerNum).set({
      distance: 0,
      name: "test",
      rank: 0
    });
  }

  async getGameStateOnce() {
    await database.ref('/' + this.gameRoomKey + '/gameState').once('value').then((snapshot) => {
      this.gameState = snapshot.val();
    });
  }
  getGameState() {
    database.ref('/' + this.gameRoomKey + '/gameState').on("value", (snapshot) => {
      this.gameState = snapshot.val();
    });
  }



  start(){
    this.getGameStateOnce();
    this.getGameState();

    if(this.gameState === 0){
      player = new Player();
      
      if(playerCountRef.exists()){
        playerCount = playerCountRef.val();
        player.getCount();
      }
      
    }

    car1 = createSprite(100,200);
    car1.addImage(carImg);
    car2 = createSprite(300,200);
    car2.addImage(car2Img);
    car3 = createSprite(500,200);
    car3.addImage(car3Img);
    car4 = createSprite(700,200);
    car4.addImage(car4Img);
    cars = [car1, car2, car3, car4];
  }

  play(){
    //form.hide();

    Player.getPlayerInfo();
    player.getCarEnd();
    
    if(allPlayers !== undefined) {
      background(track);
      //var display_position = 100;
      
      //index of the array
      var index = 0;

      //x and y position of the cars
      var y;
      var x = 150;

      for(var plr in allPlayers){
        //add 1 to the index for every loop

        index+=1;
        //position the cars a little away from each other in x direction

       // x+=200
        //use data form the database to display the cars in y direction
        y = displayHeight - allPlayers[plr].distance;
        
        switch(index) {
          case 1: {cars[index-1].x = 700
          break;}
          case 2: {cars[index-1].x = 900
            break;}
            case 3: {cars[index-1].x = 1100
              break;}
          default: {cars[index-1].x = 500;}

        }
        //cars[index-1].x = x;
        cars[index-1].y = y;

        if (index === player.index){
          cars[index-1].shapeColor = "red";
          camera.position.x = displayWidth/2;
          camera.position.y = cars[index-1].y
        }
       
        //textSize(15);
        //text(allPlayers[plr].name + ": " + allPlayers[plr].distance, 120,display_position)
      }

    }

    if (keyIsDown(UP_ARROW) && player.index !== null){
      player.distance +=10
      player.update();
    }

    if (player.distance >= 3800) {
      gameState = 2;
      player.rank += 1;
      Player.updateCarEnd(player.rank);
    }

    drawSprites();
  }

  end() {
    if (this.localEnd === false) {
      console.log("Game Ended");
      console.log(player.rank);
      Game.update(2);
      this.localEnd = true;
    }
  }
}
